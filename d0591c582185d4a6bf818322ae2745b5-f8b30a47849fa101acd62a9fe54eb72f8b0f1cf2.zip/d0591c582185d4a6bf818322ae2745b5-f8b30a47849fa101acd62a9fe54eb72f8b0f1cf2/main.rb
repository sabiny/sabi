def hola mundo
  if @nombres.nil?
    puts "..."
  elsif @nombres.respond_to?("each")
    @nombres.each do |nombre|
      puts "Hola #{nombre}"
    end
  else
    puts "Hola #{@nombres}"
  end
end